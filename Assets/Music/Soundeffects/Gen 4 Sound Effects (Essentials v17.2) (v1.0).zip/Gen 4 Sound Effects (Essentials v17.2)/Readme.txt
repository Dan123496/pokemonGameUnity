=============================
GEN 4 SOUND EFFECTS (ESSENTIALS v17.2)
Last Modified: 7/11/2018 (v1.0)
Compiled by Deo
https://reliccastle.com/
=============================

In version 17 of Essentials, various sound effects were swapped out for rips of gen 3 sound effects with unnecessary and inaccurate reverb. This reverb is distracting to players and other developers, thus this pack can be used as a solution.

Simply paste the SE and ME folders into your project's Audio folder, and overwrite the sound effects when prompted to. After that, go through and delete the .ogg audio files if there's a .wav file with the same name.

I ripped these sound effects myself, so please consider giving credit if you do use them! It took a fair bit of effort to rip these! While there aren't replacements for all of the default Essentials sound effects, there's quite a few extra sound effects for menus, footstep sounds, and the like.

Unfortunately, some sound effects weren't ripped (the PC, various battle sound effects), thus I have opted to include some proper gen 3 sound effects as a substitute so your remaining sound effects don't have any reverb. Please consider giving iteachvader (https://www.sounds-resource.com/submitter/iteachvader/) credit if you use these. They're in the SE and ME folders with (Gen 3) in the name respectively.

It should also be noted that some of the sound effects in this pack may have a different volume than some other sound effects included in Essentials or other packs.

=============================